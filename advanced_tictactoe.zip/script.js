const board = document.getElementById('gameBoard');
const statusText = document.getElementById('statusText');
const restartBtn = document.getElementById('restartBtn');
const resetScoresBtn = document.getElementById('resetScoresBtn');
const toggleModeBtn = document.getElementById('toggleModeBtn');
const modeToggleBtn = document.getElementById('modeToggleBtn');
const muteBtn = document.getElementById('muteBtn');

const playerXScoreEl = document.getElementById('playerXScore');
const playerOScoreEl = document.getElementById('playerOScore');

const clickSound = document.getElementById('clickSound');
const winSound = document.getElementById('winSound');
const drawSound = document.getElementById('drawSound');

let options = Array(9).fill("");
let currentPlayer = "X";
let isRunning = false;
let isMuted = false;
let isPvP = false;
let scores = { X: 0, O: 0 };

const winConditions = [
  [0,1,2], [3,4,5], [6,7,8],
  [0,3,6], [1,4,7], [2,5,8],
  [0,4,8], [2,4,6]
];

function playSound(sound) {
  if (!isMuted) sound.play();
}

function startGame() {
  board.innerHTML = '';
  options = Array(9).fill("");
  currentPlayer = "X";
  isRunning = true;
  statusText.textContent = \`Turn: \${currentPlayer}\`;

  options.forEach((_, index) => {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.index = index;
    cell.addEventListener('click', cellClicked);
    board.appendChild(cell);
  });
}

function cellClicked() {
  const index = this.dataset.index;
  if (options[index] || !isRunning) return;

  makeMove(index, currentPlayer);
  if (checkWinner(currentPlayer)) return;

  if (!isPvP && currentPlayer === "X") {
    setTimeout(() => {
      const bestMove = minimax(options, "O").index;
      makeMove(bestMove, "O");
      checkWinner("O");
    }, 400);
  } else {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusText.textContent = \`Turn: \${currentPlayer}\`;
  }
}

function makeMove(index, player) {
  options[index] = player;
  board.children[index].textContent = player;
  playSound(clickSound);
}

function checkWinner(player) {
  let winLine = null;

  for (let condition of winConditions) {
    const [a, b, c] = condition;
    if (options[a] === player && options[b] === player && options[c] === player) {
      winLine = [a, b, c];
      break;
    }
  }

  if (winLine) {
    winLine.forEach(index => {
      board.children[index].classList.add('winner');
    });
    statusText.textContent = \`\${player} wins!\`;
    scores[player]++;
    updateScores();
    isRunning = false;
    playSound(winSound);
    return true;
  }

  if (!options.includes("")) {
    statusText.textContent = \`It's a draw!\`;
    isRunning = false;
    playSound(drawSound);
    return false;
  }

  return false;
}

function updateScores() {
  playerXScoreEl.textContent = scores.X;
  playerOScoreEl.textContent = scores.O;
}

function minimax(newBoard, player) {
  const huPlayer = "X";
  const aiPlayer = "O";
  const availSpots = newBoard.map((v, i) => v === "" ? i : null).filter(i => i !== null);

  if (checkWin(newBoard, huPlayer)) return { score: -10 };
  if (checkWin(newBoard, aiPlayer)) return { score: 10 };
  if (availSpots.length === 0) return { score: 0 };

  const moves = [];

  for (let i = 0; i < availSpots.length; i++) {
    const move = {};
    move.index = availSpots[i];
    newBoard[availSpots[i]] = player;

    const result = minimax(newBoard, player === aiPlayer ? huPlayer : aiPlayer);
    move.score = result.score;

    newBoard[availSpots[i]] = "";
    moves.push(move);
  }

  let bestMove;
  if (player === aiPlayer) {
    let bestScore = -Infinity;
    moves.forEach((move, i) => {
      if (move.score > bestScore) {
        bestScore = move.score;
        bestMove = i;
      }
    });
  } else {
    let bestScore = Infinity;
    moves.forEach((move, i) => {
      if (move.score < bestScore) {
        bestScore = move.score;
        bestMove = i;
      }
    });
  }

  return moves[bestMove];
}

function checkWin(board, player) {
  return winConditions.some(([a, b, c]) => board[a] === player && board[b] === player && board[c] === player);
}

restartBtn.addEventListener('click', startGame);

resetScoresBtn.addEventListener('click', () => {
  scores.X = 0;
  scores.O = 0;
  updateScores();
});

toggleModeBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark');
});

modeToggleBtn.addEventListener('click', () => {
  isPvP = !isPvP;
  modeToggleBtn.textContent = \`Mode: \${isPvP ? "PvP" : "PvAI"}\`;
  startGame();
});

muteBtn.addEventListener('click', () => {
  isMuted = !isMuted;
  muteBtn.textContent = isMuted ? "🔇 Muted" : "🔊 Sound";
});

startGame();
